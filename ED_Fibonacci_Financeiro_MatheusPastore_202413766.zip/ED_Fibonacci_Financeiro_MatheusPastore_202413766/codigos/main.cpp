#include <iostream>
#include "fib_market_api.h"

int main()
{
    // Dados de mercado simulados (movimento de alta)
    const double precoBaixo = 20.00; // Swing Low
    const double precoAlto = 30.00;  // Swing High
    const int tendencia = 1;         // 1 = alta; 0 = baixa.

    std::cout << "Iniciando predicao de mercado via API Fibonacci...\n\n";

    // Chamada da funcao exportada pela biblioteca compartilhada
    calcularRetracoes(precoBaixo, precoAlto, tendencia);

    return 0;
}
