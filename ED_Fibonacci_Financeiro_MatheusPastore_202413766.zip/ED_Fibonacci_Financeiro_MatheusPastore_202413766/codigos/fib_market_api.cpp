#define BUILDING_DLL
#include "fib_market_api.h"
#include <iostream>
#include <iomanip>
#include <cmath>

void calcularRetracoes(double baixo, double alto, int tendencia) {
    const double amplitude = std::fabs(alto - baixo);

    // Niveis classicos de Fibonacci.
    const double n236 = 0.236;
    const double n382 = 0.382;
    const double n500 = 0.500;
    const double n618 = 0.618;

    std::cout << std::fixed << std::setprecision(2);
    std::cout << "=== ANALISE DE RETRACAO FIBONACCI ===\n";
    std::cout << "Swing Low : " << baixo << "\n";
    std::cout << "Swing High: " << alto << "\n";
    std::cout << "Amplitude : " << amplitude << "\n\n";

    if (tendencia == 1) { // Tendencia de alta -> niveis de suporte
        std::cout << "Tendencia: ALTA (procurando suportes)\n";
        std::cout << "23.6% : " << (alto - amplitude * n236) << "\n";
        std::cout << "38.2% : " << (alto - amplitude * n382) << "\n";
        std::cout << "50.0% : " << (alto - amplitude * n500) << "\n";
        std::cout << "61.8% : " << (alto - amplitude * n618) << "\n";
    } else { // Tendencia de baixa -> niveis de resistencia
        std::cout << "Tendencia: BAIXA (procurando resistencias)\n";
        std::cout << "23.6% : " << (baixo + amplitude * n236) << "\n";
        std::cout << "38.2% : " << (baixo + amplitude * n382) << "\n";
        std::cout << "50.0% : " << (baixo + amplitude * n500) << "\n";
        std::cout << "61.8% : " << (baixo + amplitude * n618) << "\n";
    }
    std::cout << "====================================\n";
}
