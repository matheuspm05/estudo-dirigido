#ifndef FIB_MARKET_API_H
#define FIB_MARKET_API_H

// Biblioteca compartilhada para retracoes de Fibonacci.
// baixo e alto: precos em reais (BRL).
// tendencia: 1 = alta (suportes); 0 = baixa (resistencias).
// Saida: texto no stdout com duas casas decimais.
#if defined(_WIN32)
#ifdef BUILDING_DLL
#define API_EXPORT __declspec(dllexport)
#else
#define API_EXPORT __declspec(dllimport)
#endif
#else
#define API_EXPORT __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C"
{
#endif

    /* Calcula e imprime os niveis de retracao de Fibonacci.
    tendencia = 1 (alta) ou 0 (baixa). */
    API_EXPORT void calcularRetracoes(double baixo, double alto, int tendencia);

#ifdef __cplusplus
}
#endif

#endif // FIB_MARKET_API_H
